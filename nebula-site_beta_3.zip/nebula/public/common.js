const h = (t, p = {}, ...c) => { const e = document.createElement(t); for (const k in p) { if (k.startsWith('on')) e.addEventListener(k.slice(2), p[k]); else e.setAttribute(k, p[k]); } c.flat().forEach(x => e.append(x ?? '')); return e; };
async function api(u, m = 'GET', b) {
  const r = await fetch(u, { method: m, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' }, body: b ? JSON.stringify(b) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(d.error || 'Ошибка'); e.status = r.status; e.retry = d.retry; throw e; }
  return d;
}
const fmt = t => new Date(t).toLocaleString('ru-RU');

const SVG = {
  lock: '<rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  play: '<rect x="3" y="4.5" width="18" height="15" rx="3.5"/><path d="M10 9l5 3-5 3z"/>',
  code: '<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13.5 6l-3 12"/>',
  cube: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>',
  wa: '<path d="M3.5 20.5l1.4-4.3A8.5 8.5 0 1 1 8.3 19.3z"/><path d="M9 8.8c.2 2.4 2.8 5 5.4 5.4l1.2-1.3-1.9-1-.9.8c-.8-.3-1.8-1.3-2.1-2.1l.8-.9-1-1.9z"/>',
  tg: '<path d="M21 4L3 11l6 2.2L11 20l3-4 4.5 3.3z"/><path d="M9 13.2L21 4"/>'
};
const ico = (n, s = 24) => { const e = document.createElement('span'); e.className = 'ico'; e.innerHTML = `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${SVG[n]}</svg>`; return e; };
// закрытый замок, перетянутый цепью
const chainLock = (s = 40) => { const e = document.createElement('span'); e.className = 'ico chain'; e.title = 'Откроется после покупки';
  e.innerHTML = `<svg viewBox="0 0 48 48" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="25" width="15" height="7" rx="3.5" transform="rotate(-16 9 28)"/><rect x="31" y="30" width="15" height="7" rx="3.5" transform="rotate(-16 38 33)"/><path d="M19 22v-4.5a5 5 0 0 1 10 0V22"/><rect x="15" y="22" width="18" height="16" rx="3.5" fill="var(--bg)"/><circle cx="24" cy="29.5" r="1.6"/><path d="M24 31v3"/></svg>`; return e; };

const COURSES = [
  { id: 'ai', t: 'ИИ: картинки и видео', d: 'Создание изображений и видео с помощью нейросетей', i: 'play' },
  { id: 'web', t: 'Разработка сайтов', d: 'Сайты с помощью ИИ: от идеи до запуска', i: 'code' },
  { id: '3d', t: '3D-моделирование', d: 'Модели, сцены и визуализация с помощью ИИ', i: 'cube' }];
const COURSE_SHORT = { ai: 'ИИ', web: 'Сайты', '3d': '3D' };
// c — сколько курсов входит (по порядку: ИИ → Сайты → 3D); x — дополнительные пункты
const PK = [
  { id: 'start', n: 'Start', price: '25 000', d: 'Первый шаг в мире нейросетей', c: 1, x: ['Тесты и результаты'] },
  { id: 'create', n: 'Create', price: '40 000', d: 'Два направления в одном пакете', c: 2, pop: 1, x: ['Тесты и результаты'] },
  { id: 'ultimate', n: 'Ultimate', price: '50 000', d: 'Все три направления', c: 3, x: ['Тесты и результаты'] },
  { id: 'plus', n: 'Ultimate Plus', price: '100 000', d: 'Личное сопровождение', c: 3, x: ['Индивидуальная работа', 'Поддержка нашей команды'] }];
const waLink = t => `https://wa.me/${CFG.wa}?text=${encodeURIComponent(t)}`;

// Рисованный росток → ромашка: чем дороже пакет, тем он больше расцвёл (1..4)
const plant = n => {
  const ink = '#2a2540', leaf = '#a9c3a0', pet = '#fff', cen = '#e08a5b', st = `stroke="${ink}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"`;
  const stems = { 1: ['M40 70 C40 64 41 60 40 55', 55], 2: ['M40 70 C39 62 41 54 40 46', 46], 3: ['M40 70 C39 56 41 44 40 34', 34], 4: ['M40 70 C39 58 41 50 40 40', 40] };
  const lv = { 1: ['M40 61 C34 60 31 56 31 52 C36 52 39 55 40 61Z', 'M40 58 C45 57 48 53 48 50 C43 50 40 53 40 58Z'],
    2: ['M40 63 C34 63 30 59 30 54 C35 54 39 57 40 63Z', 'M40 58 C46 58 50 54 50 49 C45 49 41 52 40 58Z'],
    3: ['M40 62 C29 62 23 55 23 48 C32 48 39 53 40 62Z', 'M40 53 C51 53 57 46 57 39 C48 39 41 45 40 53Z'],
    4: ['M40 63 C28 63 21 55 21 47 C31 47 39 53 40 63Z', 'M40 55 C52 55 59 47 59 39 C49 39 41 46 40 55Z'] };
  let g = `<path d="M18 71 Q40 67 62 71" ${st} fill="none"/><path d="M28 75h6M44 75h8" ${st} fill="none" opacity=".5"/>`;
  g += `<path d="${stems[n][0]}" ${st} fill="none"/>` + lv[n].map(d => `<path d="${d}" ${st} fill="${leaf}"/>`).join('');
  const petals = (cx, cy, k, rx, ry, d) => Array.from({ length: k }, (_, i) => `<ellipse cx="${cx}" cy="${cy - d}" rx="${rx}" ry="${ry}" transform="rotate(${i * 360 / k} ${cx} ${cy})" ${st} fill="${pet}"/>`).join('');
  if (n === 2) g += `<ellipse cx="40" cy="40" rx="3" ry="6.5" transform="rotate(-26 40 46)" ${st} fill="${pet}"/><ellipse cx="40" cy="40" rx="3" ry="6.5" transform="rotate(26 40 46)" ${st} fill="${pet}"/><circle cx="40" cy="43" r="2" fill="${cen}"/><ellipse cx="40" cy="39.5" rx="3.1" ry="7" ${st} fill="${pet}"/>`;
  if (n === 3) g += petals(40, 24, 6, 4.2, 8, 9) + `<circle cx="40" cy="24" r="4.5" ${st} fill="${cen}"/>`;
  if (n === 4) g += petals(40, 26, 10, 4, 11, 12) + `<circle cx="40" cy="26" r="6.5" ${st} fill="${cen}"/><path d="M12 22v6M9 25h6M68 12v6M65 15h6" stroke="${cen}" stroke-width="2" stroke-linecap="round"/>`;
  const e = document.createElement('span'); e.className = 'plant'; e.innerHTML = `<svg viewBox="0 0 80 80" width="76" height="76" aria-hidden="true">${g}</svg>`; return e;
};
// цепь, обхватывающая закрытую карточку
const chainFrame = () => {
  const e = document.createElement('span'); e.className = 'frame';
  const B = t => { const u = 1 - t; return [u*u*364 + 2*u*t*180 + t*t*(-4), u*u*18 + 2*u*t*108 + t*t*50]; };
  let g = '', n = 17;
  for (let k = 0; k <= n; k++) {
    const t = k / n, [x, y] = B(t), [x1, y1] = B(Math.max(0, t - .02)), [x2, y2] = B(Math.min(1, t + .02));
    const a = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;
    g += k % 2
      ? `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${a.toFixed(1)})"><rect x="-8" y="-2.6" width="16" height="5.2" rx="2.6" class="le"/></g>`
      : `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${a.toFixed(1)})"><rect x="-11" y="-6" width="22" height="12" rx="6" class="lk"/><rect x="-11" y="-6" width="22" height="12" rx="6" class="lg"/></g>`;
  }
  g += `<g transform="translate(180 66)"><path d="M-9 8V-2a9 9 0 0 1 18 0V8" class="sh"/><rect x="-17" y="6" width="34" height="29" rx="8" class="lb"/><circle cx="0" cy="19" r="3.6" class="kh"/><path d="M0 21v7" class="kh2"/></g>`;
  e.innerHTML = `<svg viewBox="0 0 360 110" width="100%" aria-hidden="true">${g}</svg>`;
  return e;
};

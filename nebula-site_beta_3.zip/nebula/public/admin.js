const app=document.getElementById('app'),nav=document.getElementById('nav');const mount=(...n)=>app.replaceChildren(...n);
const tabs={users:['Ученики',usersTab],lessons:['Уроки и тесты',lessonsTab],faq:['О курсах',faqTab],results:['Результаты',resultsTab]};
let selUser=null;
async function init(){try{await api('/api/admin/users');panel('users')}catch{loginView()}}
function loginView(){const e=h('p',{class:'err'}),l=h('input',{placeholder:'Логин админа'}),p=h('input',{type:'password',placeholder:'Пароль'});
 mount(h('form',{class:'card',onsubmit:async x=>{x.preventDefault();try{await api('/api/admin/login','POST',{login:l.value,password:p.value});init()}catch(z){e.textContent=z.message}}},l,p,h('button',{class:'btn dark'},'Войти'),e))}
async function panel(t,arg){nav.replaceChildren(h('button',{class:'btn sm',onclick:async()=>{await api('/api/admin/logout','POST');location.reload()}},'Выйти'));
 const bar=h('div',{class:'tabs'},Object.entries(tabs).map(([k,v])=>h('button',{class:'btn sm'+(k===t?' dark':''),onclick:()=>panel(k)},v[0])));
 try{mount(bar,await tabs[t][1](arg))}catch(e){e.status===401?loginView():mount(bar,h('p',{class:'err'},e.message))}}
let lastCreds=null;
const copyText=async t=>{try{await navigator.clipboard.writeText(t);return true}catch{return false}};
const clientMsg=c=>`Здравствуйте! Оплата получена ✅\nСайт: ${location.origin}\nЛогин: ${c.login}\nПароль: ${c.password}\n\nАккаунт личный: не передавайте его другим. Он привязывается к вашим устройствам (до 2), с чужих войти не получится.`;
async function usersTab(){const us=await api('/api/admin/users'),box=h('div',{}),l=h('input',{placeholder:'Логин (например, имя клиента)'}),p=h('input',{placeholder:'Пароль (пусто = сгенерировать)'});
 const cur=us.find(u=>u.id===selUser)||us[0];if(cur)selUser=cur.id;
 const add=h('div',{class:'row'},l,p,h('button',{class:'btn dark sm',onclick:async()=>{try{const r=await api('/api/admin/users','POST',{login:l.value,password:p.value});lastCreds=r;selUser=r.id;panel('users')}catch(e){box.replaceChildren(h('p',{class:'err'},e.message))}}},'Создать аккаунт'));
 const instr=h('div',{class:'card instr'},h('h3',{},'Как выдать доступ клиенту'),h('ol',{},
  h('li',{},'Клиент оплатил в WhatsApp или Telegram.'),
  h('li',{},'Внизу, в «Новый ученик», введите логин и нажмите «Создать аккаунт». Пароль создаётся сам и показывается один раз.'),
  h('li',{},'В блоке «Доступ ученика» выберите пакет (Start, Create, Ultimate, Ultimate Plus) — нужные курсы отметятся сами. Нажмите «Сохранить».'),
  h('li',{},'Нажмите «Скопировать сообщение» и отправьте клиенту в мессенджер.'),
  h('li',{},'Аккаунт привяжется к первым двум устройствам клиента. Сменил телефон — нажмите «Сбросить привязку».')));
 const credCard=lastCreds?h('div',{class:'card ok-card'},h('h3',{},'Аккаунт создан'),h('p',{},`Логин: ${lastCreds.login} · Пароль: ${lastCreds.password}`),h('p',{class:'hint'},'Пароль больше не покажется — скопируйте сообщение сейчас. Теперь выберите пакет ниже.'),
  h('p',{},h('button',{class:'btn dark sm',onclick:async e=>{e.target.textContent=(await copyText(clientMsg(lastCreds)))?'Скопировано ✓':'Не удалось — выделите текст вручную'}},'Скопировать сообщение клиенту'),' ',h('button',{class:'btn sm',onclick:()=>{lastCreds=null;panel('users')}},'Скрыть'))):'';
 let access='';
 if(cur){let pkg=cur.pkg||null;const on=new Set((cur.courses||'').split(',').filter(Boolean)),pb=h('span',{class:'chips'}),cb=h('span',{class:'chips'}),msg=h('span',{class:'ok'});
  const draw=()=>{pb.replaceChildren(...PK.map(k=>h('button',{class:'chip'+(pkg===k.id?' on':''),onclick:()=>{pkg=k.id;on.clear();COURSES.slice(0,k.c).forEach(c=>on.add(c.id));draw()}},k.n)));
   cb.replaceChildren(...COURSES.map(c=>h('button',{class:'chip'+(on.has(c.id)?' on':''),onclick:()=>{on.has(c.id)?on.delete(c.id):on.add(c.id);draw()}},(on.has(c.id)?'✓ ':'')+c.t)))};draw();
  access=h('div',{class:'card acc-card'},h('h3',{},'Доступ ученика: '+cur.login),
   h('div',{class:'arow'},h('b',{},'Пакет:'),pb),h('div',{class:'arow'},h('b',{},'Доступные курсы:'),cb),
   h('p',{class:'hint'},'Start — ИИ; Create — ИИ и сайты; Ultimate и Ultimate Plus — все три. После выбора пакета галочки можно поправить вручную.'),
   h('p',{},h('button',{class:'btn dark sm',onclick:async()=>{try{await api(`/api/admin/users/${cur.id}/access`,'PUT',{pkg,courses:[...on]});msg.textContent=' Сохранено ✓';setTimeout(()=>panel('users'),700)}catch(e){msg.textContent=' '+e.message}}},'Сохранить'),msg))}
 const pname=k=>(PK.find(x=>x.id===k)||{}).n||'—',cname=u=>(u.courses||'').split(',').filter(Boolean).map(c=>COURSE_SHORT[c]).join(', ')||'—';
 return h('div',{},instr,credCard,access,h('table',{class:'ut'},h('tr',{},['Логин','Пакет','Курсы','Устройства','Последний IP',''].map(x=>h('th',{},x))),us.map(u=>h('tr',{},h('td',{},u.login),h('td',{},pname(u.pkg)),h('td',{},cname(u)),h('td',{},String(u.devices)),h('td',{},u.ip||'ещё не входил'),h('td',{class:'acts'},
  h('button',{class:'btn sm',onclick:()=>{selUser=u.id;panel('users')}},'Доступ'),' ',
  h('button',{class:'btn sm',onclick:async()=>{if(confirm('Сбросить привязку устройств у '+u.login+'?')){await api(`/api/admin/users/${u.id}/reset`,'POST');panel('users')}}},'Сбросить привязку'),' ',
  h('button',{class:'btn red sm',onclick:async()=>{if(confirm('Удалить все ответы и результаты тестов у '+u.login+'?')){await api(`/api/admin/users/${u.id}/answers`,'DELETE');panel('users')}}},'Очистить историю'),' ',
  h('button',{class:'btn red sm',onclick:async()=>{if(confirm('Удалить '+u.login+'?')){await api('/api/admin/users/'+u.id,'DELETE');panel('users')}}},'Удалить'))))),
  h('div',{class:'card gap'},h('h3',{},'Новый ученик'),add,box),
  h('div',{class:'card gap'},h('h3',{},'Резервная копия базы'),h('p',{class:'hint'},'Сервер сам делает копию каждые 12 часов (хранятся последние 14). Раз в неделю скачивайте копию себе на компьютер.'),h('a',{class:'btn sm',href:'/api/admin/backup'},'Скачать копию сейчас')))}
async function lessonsTab(){const ls=await api('/api/admin/lessons'),t=h('input',{placeholder:'Заголовок'}),b=h('textarea',{rows:5,placeholder:'Текст урока (абзацы — через пустую строку)'}),k=h('select',{},h('option',{value:'lesson'},'Урок'),h('option',{value:'test'},'Отдельный тест')),cs=h('select',{},COURSES.map(c=>h('option',{value:c.id},'Раздел: '+c.t)));
 return h('div',{},h('div',{class:'card'},h('h3',{},'Добавить'),k,cs,t,b,h('p',{},h('button',{class:'btn dark sm',onclick:async()=>{const r=await api('/api/admin/lessons','POST',{kind:k.value,course:cs.value,title:t.value,body:b.value});panel('edit',r.id)}},'Создать'))),
  h('table',{},ls.map(l=>h('tr',{},h('td',{},(l.kind==='test'?'🧪 ':'📘 ')+l.title+' · '+(COURSE_SHORT[l.course]||'ИИ')),h('td',{},h('button',{class:'btn sm',onclick:()=>panel('edit',l.id)},'Править / вопросы'),' ',h('button',{class:'btn red sm',onclick:async()=>{if(confirm('Удалить вместе с вопросами и результатами?')){await api('/api/admin/lessons/'+l.id,'DELETE');panel('lessons')}}},'Удалить'))))))}
tabs.edit=['',async id=>{const l=await api('/api/admin/lessons/'+id),ce=h('select',{},COURSES.map(c=>h('option',Object.assign({value:c.id},c.id===(l.course||'ai')?{selected:''}:{}),'Раздел: '+c.t))),t=h('input',{value:l.title}),b=h('textarea',{rows:8},l.body),msg=h('span',{}),
 qt=h('input',{placeholder:'Вопрос'}),os=[0,1,2,3].map(i=>h('input',{placeholder:'Вариант '+(i+1)})),c=h('select',{},[0,1,2,3].map(i=>h('option',{value:i},'Верный: вариант '+(i+1))));
 const vf=h('input',{type:'file',accept:'video/mp4,video/webm'}),vp=h('progress',{max:100,value:0}),vm=h('p',{class:'sub'},l.video?'✅ Видео загружено':'Видео пока нет');vp.hidden=true;
 const up=()=>{const f=vf.files[0];if(!f)return alert('Сначала выберите файл');const x=new XMLHttpRequest();x.open('PUT','/api/admin/lessons/'+id+'/video');x.setRequestHeader('X-Requested-With','fetch');
  x.setRequestHeader('Content-Type',f.type||(/\.webm$/i.test(f.name)?'video/webm':'video/mp4'));vp.hidden=false;
  x.upload.onprogress=e=>{vp.value=e.loaded/e.total*100;vm.textContent='Загрузка: '+Math.round(vp.value)+'% (не закрывайте страницу)'};
  x.onload=()=>x.status===200?panel('edit',id):(vm.textContent='Ошибка: '+(JSON.parse(x.responseText||'{}').error||x.status));x.onerror=()=>vm.textContent='Ошибка сети';x.send(f)};
 const vcard=h('div',{class:'card'},h('h3',{},'Видео урока'),vm,h('div',{class:'row'},vf,h('button',{class:'btn dark sm',onclick:up},'Загрузить')),vp,l.video?h('button',{class:'btn red sm',onclick:async()=>{await api('/api/admin/lessons/'+id+'/video','DELETE');panel('edit',id)}},'Удалить видео'):'');
 return h('div',{},h('a',{href:'#',onclick:e=>{e.preventDefault();panel('lessons')}},'← Назад'),h('div',{class:'card'},ce,t,b,h('p',{},h('button',{class:'btn dark sm',onclick:async()=>{await api('/api/admin/lessons/'+id,'PUT',{title:t.value,body:b.value,course:ce.value});msg.textContent=' Сохранено'}},'Сохранить'),msg)),vcard,
  h('div',{class:'card'},h('h3',{},'Вопросы теста'),l.questions.map(q=>h('div',{class:'row'},h('span',{},q.text+' → '+q.opts[q.correct]),h('button',{class:'btn red sm',onclick:async()=>{await api('/api/admin/questions/'+q.id,'DELETE');panel('edit',id)}},'✕'))),
   h('hr'),qt,...os,c,h('p',{},h('button',{class:'btn dark sm',onclick:async()=>{try{await api(`/api/admin/lessons/${id}/questions`,'POST',{text:qt.value,opts:os.map(o=>o.value),correct:+c.value});panel('edit',id)}catch(e){alert(e.message)}}},'Добавить вопрос'))))}];
async function faqTab(){const fs=await api('/api/admin/faq'),nt=h('input',{placeholder:'Заголовок (например: Как проходит обучение)'}),nb=h('textarea',{rows:4,placeholder:'Текст, который раскрывается по плюсу'});
 return h('div',{},h('div',{class:'card'},h('h3',{},'Блок «О курсах» на главной у ученика'),h('p',{class:'hint'},'Каждый пункт на сайте раскрывается по кнопке «+». Пишите свой текст здесь.')),
  ...fs.map(f=>{const t=h('input',{value:f.title}),b=h('textarea',{rows:4},f.body),m=h('span',{class:'ok'});return h('div',{class:'card gap'},t,b,h('p',{},h('button',{class:'btn dark sm',onclick:async()=>{await api('/api/admin/faq/'+f.id,'PUT',{title:t.value,body:b.value});m.textContent=' Сохранено'}},'Сохранить'),' ',h('button',{class:'btn red sm',onclick:async()=>{if(confirm('Удалить этот пункт?')){await api('/api/admin/faq/'+f.id,'DELETE');panel('faq')}}},'Удалить'),m))}),
  h('div',{class:'card gap'},h('h3',{},'Добавить пункт'),nt,nb,h('p',{},h('button',{class:'btn dark sm',onclick:async()=>{try{await api('/api/admin/faq','POST',{title:nt.value,body:nb.value});panel('faq')}catch(e){alert(e.message)}}},'Добавить'))))}
async function resultsTab(){const rs=await api('/api/admin/results');return rs.length?h('table',{},h('tr',{},['Ученик','Урок / тест','Баллы','Дата'].map(x=>h('th',{},x))),rs.map(r=>h('tr',{},h('td',{},r.login),h('td',{},r.title),h('td',{},`${r.score} / ${r.total}`),h('td',{},fmt(r.at))))):h('p',{class:'sub'},'Пока нет результатов')}
addEventListener('unhandledrejection',e=>{e.preventDefault();const r=e.reason||{};if(r.status===401)return loginView();alert(r.message||'Ошибка. Попробуйте ещё раз.')});
init();

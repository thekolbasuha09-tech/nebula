const app = document.getElementById('app'), nav = document.getElementById('nav');
let me = null, info = null;
const mount = (...n) => app.replaceChildren(...n);
const scrollTo = id => e => { e && e.preventDefault(); const x = document.getElementById(id); x && x.scrollIntoView({ behavior: 'smooth' }); };

// ---------- окна ----------
const modal = (...c) => { const m = h('div', { class: 'modal', onclick: e => { if (e.target === m) m.classList.remove('open'); } }, ...c); return m; };
const closeBtn = m => h('button', { class: 'x', 'aria-label': 'Закрыть', onclick: () => m.classList.remove('open') }, '×');

// «Купить» / «Написать»: выбор WhatsApp или Telegram (одинаково везде)
const contact = modal(), openContact = (title, text) => {
  contact.replaceChildren(h('div', { class: 'box' }, closeBtn(contact), h('h3', {}, title),
    h('p', { class: 'sub' }, 'Напишите нам в удобный мессенджер — подскажем по оплате и выдадим доступ.'),
    h('p', { class: 'msg' }, '«' + text + '»'),
    h('div', { class: 'stack' },
      h('a', { class: 'btn wa', href: waLink(text), target: '_blank', rel: 'noopener' }, ico('wa', 18), 'Написать в WhatsApp'),
      h('a', { class: 'btn tgb', href: CFG.tg, target: '_blank', rel: 'noopener' }, ico('tg', 18), 'Написать в Telegram')),
    h('p', { class: 'fine' }, 'WhatsApp ' + CFG.phone + ' · Telegram @nebula_smart')));
  contact.classList.add('open');
};

function loginModal() {
  const err = h('p', { class: 'err' }), l = h('input', { placeholder: 'Логин', autocomplete: 'username', required: '' }), p = h('input', { type: 'password', placeholder: 'Пароль', autocomplete: 'current-password', required: '' }), b = h('button', { class: 'btn dark' }, 'Войти');
  let timer = null;
  const block = s => { b.disabled = true; clearInterval(timer); const t = () => { b.textContent = s > 0 ? `Подождите ${s} с` : 'Войти'; if (s-- <= 0) { clearInterval(timer); b.disabled = false; err.textContent = ''; } }; t(); timer = setInterval(t, 1000); };
  const m = modal();
  m.append(h('form', { class: 'box', onsubmit: async e => { e.preventDefault(); err.textContent = ''; b.disabled = true;
    try { await api('/api/login', 'POST', { login: l.value, password: p.value }); me = null; m.classList.remove('open'); go(); }
    catch (x) { err.textContent = x.message; if (x.retry) block(x.retry); else b.disabled = false; } } },
    closeBtn(m), h('h3', {}, 'Вход'), h('p', { class: 'sub' }, 'Логин и пароль вы получаете после оплаты.'), l, p, b, err));
  m.open = () => { m.classList.add('open'); l.focus(); };
  return m;
}
const login = loginModal();

// ---------- шапка ----------
const homeClick = e => { if (!location.hash || location.hash === '#/') { e.preventDefault(); scrollTo('top')(); go(); } };
const head = () => nav.replaceChildren(...(me
  ? [h('a', { href: '#/', onclick: homeClick }, 'Домой'), h('a', { href: '#/results' }, 'Результаты'), h('a', { href: CFG.tg, target: '_blank', rel: 'noopener' }, 'Поддержка'), h('button', { class: 'btn dark sm', onclick: logout }, 'Выйти')]
  : [h('a', { href: '#courses', onclick: scrollTo('courses') }, 'Курсы'), h('a', { href: '#packages', onclick: scrollTo('packages') }, 'Пакеты'), h('button', { class: 'btn dark sm', onclick: () => login.open() }, 'Войти')]));
async function logout() { await api('/api/logout', 'POST').catch(() => {}); me = null; info = null; location.hash = '#/'; go(); }

// ---------- общие блоки ----------
function courseCard(c, ok, lessons, inCabinet) {
  const go = () => { if (ok) location.hash = '#/course/' + c.id; else if (!inCabinet) scrollTo('packages')(); };
  const shown = lessons.slice(0, 6), more = lessons.length - shown.length;
  return h('div', { class: 'course' + (ok ? ' open' : ' locked' + (inCabinet ? ' still' : '')), role: 'button', tabindex: '0', onclick: go, onkeydown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } } },
    h('div', { class: 'ctop' }, h('span', { class: 'cico' }, ico(c.i, 22)), ok ? h('span', { class: 'badge' }, 'Доступно') : h('span', { class: 'lockb' }, ico('lock', 24))),
    h('h3', {}, c.t), h('p', { class: 'cd' }, c.d),
    h('div', { class: 'inside' }, h('small', {}, 'Что внутри'),
      lessons.length ? h('ul', {}, shown.map(l => h('li', {}, ok ? h('i', { class: 'dotx' }) : ico('lock', 14), l.title)), more > 0 ? h('li', { class: 'soon' }, `и ещё ${more}…`) : '')
        : h('p', { class: 'soon' }, 'Программа скоро появится')),
    h('span', { class: 'ccta' }, ok ? 'Открыть курс →' : (inCabinet ? 'Недоступно в вашем пакете' : 'Откроется после покупки')),
    ok ? '' : chainFrame());
}
function packages() {
  return h('section', { id: 'packages' }, h('h2', { class: 'sec' }, 'Пакеты'), h('p', { class: 'sub' }, 'Смотреть сайт можно бесплатно. Платный — доступ к урокам: он привязывается к вашему личному аккаунту.'),
    h('div', { class: 'pkgs' }, PK.map((k, i) => h('div', { class: 'pkg ' + k.id + (k.pop ? ' pop' : '') },
      h('div', { class: 'pkg-art' }, plant(i + 1)),
      h('div', { class: 'pkg-h' }, h('b', {}, k.n), k.pop ? h('span', { class: 'badge' }, 'Популярный') : ''),
      h('div', { class: 'price' }, k.price, h('small', {}, ' ₸')), h('p', { class: 'pkg-d' }, k.d),
      h('ul', {}, COURSES.slice(0, k.c).map(c => h('li', {}, h('b', {}, c.t), h('span', {}, c.d))), k.x.map(x => h('li', {}, h('b', {}, x)))),
      h('button', { class: 'btn pbtn', onclick: () => openContact('Купить пакет ' + k.n, `Здравствуйте! Хочу купить пакет ${k.n} (${k.price} ₸).`) }, 'Купить')))));
}
function faqBlock(faq) {
  if (!faq.length) return '';
  return h('section', {}, h('h2', { class: 'sec' }, 'О курсах'), h('div', { class: 'accs' }, faq.map((f, i) => { const it = h('div', { class: 'acc' + (i === 0 ? ' open' : '') }, h('button', { class: 'acc-h', onclick: () => it.classList.toggle('open') }, h('span', {}, f.title), h('i', { class: 'pm' })), h('div', { class: 'acc-b' }, h('div', { class: 'acc-in' }, h('p', { class: 'acc-t' }, f.body)))); return it; })));
}
const contactBlock = () => h('section', {}, h('h2', { class: 'sec' }, 'Остались вопросы?'),
  h('div', { class: 'cont' }, h('a', { class: 'btn wa', href: waLink('Здравствуйте! У меня вопрос по курсам Nebula.'), target: '_blank', rel: 'noopener' }, ico('wa', 18), 'Написать в WhatsApp'), h('a', { class: 'btn tgb', href: CFG.tg, target: '_blank', rel: 'noopener' }, ico('tg', 18), 'Написать в Telegram')));
const loadCommon = () => Promise.all([api('/api/catalog').catch(() => ({})), api('/api/faq').catch(() => [])]);

// ---------- страницы ----------
async function go() {
  const r = location.hash.slice(2);
  try {
    if (!me) try { info = await api('/api/me'); me = info.login; } catch {}
    head();
    if (!me) return await landingView();
    if (r.startsWith('lesson/')) return await lessonView(+r.slice(7));
    if (r.startsWith('course/')) return await courseView(r.slice(7));
    if (r === 'results') return await resultsView();
    return await homeView();
  } catch (e) { if (e.status === 401) { me = null; head(); landingView(); } else mount(h('p', { class: 'err' }, e.message)); }
}
async function landingView() {
  const [cat, faq] = await loadCommon();
  const step = (n, t, d) => h('div', { class: 'step' }, h('span', { class: 'tag' }, n), h('h3', {}, t), h('p', { class: 'sub' }, d));
  mount(h('span', { id: 'top' }),
    h('div', { class: 'hero' }, h('div', {}, h('span', { class: 'pill' }, h('i', { class: 'dot' }), 'Создавай. Генерируй. Вдохновляйся.'), h('h1', {}, 'Нейросети', h('br'), h('span', {}, 'без границ.')),
      h('p', { class: 'sub lead' }, 'Изображения, видео, сайты и 3D', h('br'), 'с помощью передовых ИИ-технологий.'),
      h('div', { class: 'cta' }, h('button', { class: 'btn dark big', onclick: scrollTo('packages') }, 'Выбрать пакет'), h('button', { class: 'btn big', onclick: () => login.open() }, 'Уже есть доступ? Войти'))),
      h('img', { class: 'art', src: '/hero.jpg', alt: 'Nebula' })),
    h('section', { id: 'how' }, h('h2', { class: 'sec' }, 'Как это работает'), h('div', { class: 'steps' },
      step('1', 'Выберите пакет', 'Нажмите «Купить» на нужном пакете — сайт открыт для всех.'), step('2', 'Оплатите', 'Напишите нам в WhatsApp или Telegram и оплатите.'),
      step('3', 'Получите доступ', 'Мы создадим для вас личный логин и пароль и пришлём их в мессенджер.'), step('4', 'Учитесь', 'Войдите, смотрите уроки и проходите тесты.'))),
    h('section', { id: 'courses' }, h('h2', { class: 'sec' }, 'Курсы'), h('div', { class: 'courses' }, COURSES.map(c => courseCard(c, false, cat[c.id] || [])))),
    packages(), faqBlock(faq), contactBlock(), login, contact);
}
async function homeView() {
  const [m, [cat, faq]] = await Promise.all([api('/api/me'), loadCommon()]); info = m;
  mount(h('span', { id: 'top' }), h('h2', { class: 'wel' }, 'Добро пожаловать, ' + m.login),
    h('div', { class: 'courses', id: 'courses' }, COURSES.map(c => courseCard(c, m.courses.includes(c.id), cat[c.id] || [], true))),
    faqBlock(faq), contactBlock(), contact);
}
async function courseView(id) {
  const c = COURSES.find(x => x.id === id); if (!c || !info.courses.includes(id)) { location.hash = '#/'; return; }
  const ls = await api('/api/lessons?course=' + id);
  mount(h('a', { href: '#/' }, '← Домой'), h('h2', {}, c.t), h('p', { class: 'sub' }, c.d),
    ls.length ? h('div', { class: 'grid' }, ls.map((l, i) => h('a', { class: 'card', href: '#/lesson/' + l.id }, h('span', { class: 'tag' }, l.kind === 'test' ? 'Тест' : 'Урок ' + (i + 1)), h('h3', {}, l.title)))) : h('p', { class: 'sub' }, 'Уроки скоро появятся.'));
}
async function lessonView(id) {
  const l = await api('/api/lessons/' + id), sel = {}, out = h('div', {}), qs = h('div', {});
  l.questions.forEach((q, qi) => qs.append(h('div', { class: 'q', id: 'q' + q.id }, h('b', {}, (qi + 1) + '. ' + q.text), q.opts.map((o, i) => h('label', {}, h('input', { type: 'radio', name: 'q' + q.id, onchange: () => sel[q.id] = i }), o)))));
  const btn = h('button', { class: 'btn dark', onclick: async () => {
    if (Object.keys(sel).length < l.questions.length) { out.replaceChildren(h('p', { class: 'err' }, 'Ответьте на все вопросы')); return; }
    const r = await api('/api/lessons/' + id + '/submit', 'POST', { answers: sel });
    l.questions.forEach(q => document.getElementById('q' + q.id).className = 'q ' + (r.ok[q.id] ? 'good' : 'bad'));
    out.replaceChildren(h('h3', { class: r.score === r.total ? 'ok' : '' }, `Результат: ${r.score} из ${r.total}`)); } }, 'Проверить');
  mount(h('a', { href: '#/course/' + l.course }, '← К курсу'), h('h2', {}, l.title),
    l.hasVideo ? h('video', { class: 'vid', controls: '', controlslist: 'nodownload', disablepictureinpicture: '', preload: 'metadata', src: '/api/lessons/' + id + '/video', oncontextmenu: e => e.preventDefault() }) : '',
    ...l.body.split(/\n{2,}/).filter(Boolean).map(t => h('p', { class: 'txt' }, t)),
    l.questions.length ? h('div', { class: 'card' }, h('h3', {}, 'Проверьте себя'), l.last ? h('p', { class: 'sub' }, `Прошлый результат: ${l.last.score} из ${l.last.total}`) : '', qs, btn, out) : '');
}
async function resultsView() {
  const rs = await api('/api/results');
  mount(h('a', { href: '#/' }, '← Домой'), h('h2', {}, 'Мои результаты'),
    rs.length ? h('table', {}, h('tr', {}, h('th', {}, 'Урок / тест'), h('th', {}, 'Баллы'), h('th', {}, 'Дата')), rs.map(r => h('tr', {}, h('td', {}, r.title), h('td', {}, `${r.score} / ${r.total}`), h('td', {}, fmt(r.at))))) : h('p', { class: 'sub' }, 'Вы ещё не проходили тесты.'),
    rs.length ? h('p', {}, h('button', { class: 'btn red sm', onclick: async () => { if (confirm('Удалить все ваши ответы и результаты тестов?')) { await api('/api/results', 'DELETE'); go(); } } }, 'Очистить историю ответов')) : '');
}
addEventListener('unhandledrejection',e=>{e.preventDefault();const r=e.reason||{};if(r.status===401){me=null;go();return}alert(r.message||'Ошибка. Попробуйте ещё раз.')});
addEventListener('hashchange', go); go();

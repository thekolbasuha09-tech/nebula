'use strict';
const express = require('express'), helmet = require('helmet'), rateLimit = require('express-rate-limit'),
  bcrypt = require('bcryptjs'), crypto = require('crypto'), fs = require('fs'), path = require('path'),
  { DatabaseSync } = require('node:sqlite');

const env = process.env, prod = env.NODE_ENV === 'production';
const DATA = path.resolve(env.DATA_DIR || __dirname);                 // папка для базы, видео и копий (на хостинге — постоянный диск)
const UP = path.join(DATA, 'uploads'), BK = path.join(DATA, 'backups');
for (const d of [DATA, UP, BK]) fs.mkdirSync(d, { recursive: true });

// ---------- админ-пароль: только из переменных окружения, в коде его нет ----------
const ADMIN_USER = env.ADMIN_USER || 'admin';
let ADMIN_PASS = env.ADMIN_PASS;
if (!ADMIN_PASS) {
  if (prod) { console.error('ОШИБКА: задайте ADMIN_PASS (минимум 12 символов) в переменных окружения.'); process.exit(1); }
  ADMIN_PASS = crypto.randomBytes(9).toString('base64url');
  console.log('Пароль админа (только для теста):', ADMIN_PASS);
}
if (prod && ADMIN_PASS.length < 12) { console.error('ОШИБКА: ADMIN_PASS короче 12 символов.'); process.exit(1); }

// ---------- база данных (SQLite, лежит вне публичной папки) ----------
const db = new DatabaseSync(path.join(DATA, 'data.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, login TEXT UNIQUE NOT NULL, hash TEXT NOT NULL, ip TEXT, sid TEXT, sid_exp INTEGER, created INTEGER, pkg TEXT, courses TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS devices(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, hash TEXT NOT NULL, created INTEGER);
CREATE TABLE IF NOT EXISTS lessons(id INTEGER PRIMARY KEY, kind TEXT DEFAULT 'lesson', title TEXT NOT NULL, body TEXT DEFAULT '', pos INTEGER DEFAULT 0, video TEXT, course TEXT DEFAULT 'ai');
CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY, lesson_id INTEGER NOT NULL, text TEXT NOT NULL, opts TEXT NOT NULL, correct INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS results(id INTEGER PRIMARY KEY, user_id INTEGER, lesson_id INTEGER, score INTEGER, total INTEGER, at INTEGER);
CREATE TABLE IF NOT EXISTS answers(id INTEGER PRIMARY KEY, user_id INTEGER, lesson_id INTEGER, question_id INTEGER, correct INTEGER, at INTEGER);
CREATE TABLE IF NOT EXISTS faq(id INTEGER PRIMARY KEY, title TEXT NOT NULL, body TEXT DEFAULT '', pos INTEGER DEFAULT 0);
CREATE INDEX IF NOT EXISTS i_users_sid ON users(sid);
CREATE INDEX IF NOT EXISTS i_dev_user ON devices(user_id);
CREATE INDEX IF NOT EXISTS i_les_course ON lessons(course);
CREATE INDEX IF NOT EXISTS i_res_user ON results(user_id, lesson_id);`);
// на случай, если база создана старой версией сайта
for (const q of ['ALTER TABLE lessons ADD COLUMN video TEXT', "ALTER TABLE lessons ADD COLUMN course TEXT DEFAULT 'ai'", 'ALTER TABLE users ADD COLUMN pkg TEXT', "ALTER TABLE users ADD COLUMN courses TEXT DEFAULT ''"]) { try { db.exec(q); } catch {} }
if (!db.prepare('SELECT COUNT(*) n FROM faq').get().n) {
  for (const t of ['Как проходит обучение', 'Что нужно для старта', 'Сколько длится каждый курс']) {
    const r = db.prepare('INSERT INTO faq(title,body) VALUES(?,?)').run(t, 'Здесь будет ваш текст. Его можно изменить в админке, вкладка «О курсах».');
    db.prepare('UPDATE faq SET pos=id WHERE id=?').run(r.lastInsertRowid);
  }
}

// ---------- настройки ----------
const CS = ['ai', 'web', '3d'], PKGS = ['start', 'create', 'ultimate', 'plus'];
const MAX_DEVICES = +env.MAX_DEVICES || 2;               // сколько устройств может быть у одного ученика
const MAXV = (+env.MAX_VIDEO_MB || 2000) * 1048576, VT = { 'video/mp4': 'mp4', 'video/webm': 'webm' };
const DAY = 864e5, HOUR = 36e5;
const sha = s => crypto.createHash('sha256').update(String(s)).digest('hex'), rnd = () => crypto.randomBytes(32).toString('hex');
const eq = (a, b) => crypto.timingSafeEqual(Buffer.from(sha(a)), Buffer.from(sha(b)));
const str = (v, m) => typeof v === 'string' && v.trim() && v.length <= m ? v.trim() : null;
const id = v => (/^\d{1,12}$/.test(String(v)) ? +v : -1);
const can = (u, c) => (u.courses || '').split(',').includes(c);
const getC = (req, n) => { const m = (req.headers.cookie || '').split(/;\s*/).find(x => x.startsWith(n + '=')); return m ? m.slice(n.length + 1) : ''; };
const cookie = (maxAge) => ({ httpOnly: true, sameSite: 'strict', secure: prod, maxAge, path: '/' });
const DUMMY = bcrypt.hashSync('dummy-password', 10);      // чтобы вход с неверным логином занимал столько же времени

// ---------- защита от подбора пароля: 3 ошибки → пауза 15 секунд ----------
const fails = new Map();
const wait = k => { const f = fails.get(k); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 1000) : 0; };
const fail = (k, max, lockMs) => { let f = fails.get(k); if (!f || (f.until && f.until <= Date.now())) f = { n: 0, until: 0 }; f.n++; f.t = Date.now(); if (f.n >= max) { f.until = Date.now() + lockMs; f.n = 0; } fails.set(k, f); };
setInterval(() => { for (const [k, f] of fails) if (Date.now() - f.t > 10 * 60e3) fails.delete(k); }, 60e3).unref();
const tooMany = (res, s) => res.status(429).json({ error: `Слишком много попыток. Подождите ${s} сек.`, retry: s });

// ---------- резервные копии ----------
function backup() {
  const f = path.join(BK, 'data-' + new Date().toISOString().replace(/[:.]/g, '-') + '.db');
  db.exec(`VACUUM INTO '${f.replace(/'/g, "''")}'`);
  const all = fs.readdirSync(BK).filter(x => x.endsWith('.db')).sort();
  for (const old of all.slice(0, Math.max(0, all.length - (+env.BACKUP_KEEP || 14)))) fs.unlink(path.join(BK, old), () => {});
  return f;
}
const safeBackup = () => { try { return backup(); } catch (e) { console.error('Ошибка резервной копии:', e.message); } };
setTimeout(safeBackup, 10e3).unref();
setInterval(safeBackup, (+env.BACKUP_HOURS || 12) * HOUR).unref();

// ---------- приложение ----------
const app = express();
const tp = env.TRUST_PROXY; app.set('trust proxy', tp === undefined ? (prod ? 1 : false) : (/^\d+$/.test(tp) ? +tp : tp === 'true'));
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], imgSrc: ["'self'", 'data:'], mediaSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"], upgradeInsecureRequests: prod ? [] : null } } }));
app.use(express.json({ limit: '100kb' }));
app.get('/healthz', (q, s) => s.type('text').send('ok'));
app.use('/api', rateLimit({ windowMs: 60e3, max: 300, skip: q => q.path.endsWith('/video'), standardHeaders: true, legacyHeaders: false, message: { error: 'Слишком много запросов. Подождите минуту.' } }));
app.use('/api', (q, s, n) => q.method !== 'GET' && q.get('x-requested-with') !== 'fetch' ? s.status(403).json({ error: 'Запрещено' }) : n());

function auth(req, res, next) {
  const s = getC(req, 'sid');
  const u = s && db.prepare('SELECT * FROM users WHERE sid=? AND sid_exp>?').get(sha(s), Date.now());
  if (!u) return res.status(401).json({ error: 'Войдите в аккаунт' });
  req.user = u; next();
}
const admins = new Map();
setInterval(() => { for (const [k, e] of admins) if (e < Date.now()) admins.delete(k); }, 10 * 60e3).unref();
const adm = (req, res, next) => { const t = getC(req, 'asid'), e = t && admins.get(sha(t)); if (!e || e < Date.now()) return res.status(401).json({ error: 'Нет доступа' }); next(); };
const clearHistory = uid => { db.prepare('DELETE FROM results WHERE user_id=?').run(uid); db.prepare('DELETE FROM answers WHERE user_id=?').run(uid); };

// ---------- публичное (без входа): программа курсов и «О курсах» ----------
app.get('/api/catalog', (q, s) => {
  const out = {}; CS.forEach(c => out[c] = []);
  for (const l of db.prepare('SELECT id,kind,title,course FROM lessons ORDER BY pos,id').all()) if (out[l.course]) out[l.course].push({ kind: l.kind, title: l.title });
  s.json(out);
});
app.get('/api/faq', (q, s) => s.json(db.prepare('SELECT id,title,body FROM faq ORDER BY pos,id').all()));

// ---------- ученик ----------
app.post('/api/login', (req, res) => {
  const l = str(req.body.login, 64), p = str(req.body.password, 128), ipk = 's:' + req.ip, lk = l ? 's:u:' + l.toLowerCase() : null;
  const w = Math.max(wait(ipk), lk ? wait(lk) : 0); if (w) return tooMany(res, w);
  const u = l && p && db.prepare('SELECT * FROM users WHERE login=?').get(l);
  const okPass = bcrypt.compareSync(p || '', u ? u.hash : DUMMY) && !!u;
  if (!okPass) { fail(ipk, 3, 15e3); if (lk) fail(lk, 3, 15e3); return res.status(401).json({ error: 'Неверный логин или пароль' }); }
  fails.delete(ipk); fails.delete(lk);
  // привязка к устройствам: до MAX_DEVICES штук, по cookie, а не по IP (IP у телефонов меняется)
  const did = getC(req, 'did'), dh = did ? sha(did) : null;
  const devs = db.prepare('SELECT hash FROM devices WHERE user_id=?').all(u.id);
  let newDid = null;
  if (!(dh && devs.some(d => d.hash === dh))) {
    if (devs.length >= MAX_DEVICES) return res.status(403).json({ error: 'Аккаунт уже привязан к другим устройствам. Напишите администратору, чтобы сбросить привязку.' });
    newDid = rnd(); db.prepare('INSERT INTO devices(user_id,hash,created) VALUES(?,?,?)').run(u.id, sha(newDid), Date.now());
  }
  const sid = rnd();   // новая сессия закрывает предыдущую: один аккаунт — один активный вход
  db.prepare('UPDATE users SET ip=?,sid=?,sid_exp=? WHERE id=?').run(req.ip, sha(sid), Date.now() + 7 * DAY, u.id);
  if (newDid) res.cookie('did', newDid, cookie(365 * DAY));
  res.cookie('sid', sid, cookie(7 * DAY)).json({ login: u.login });
});
app.post('/api/logout', (q, s) => { const c = getC(q, 'sid'); if (c) db.prepare('UPDATE users SET sid=NULL WHERE sid=?').run(sha(c)); s.clearCookie('sid').json({ ok: 1 }); });
app.get('/api/me', auth, (q, s) => s.json({ login: q.user.login, pkg: q.user.pkg || null, courses: (q.user.courses || '').split(',').filter(Boolean) }));
app.get('/api/lessons', auth, (q, s) => { const c = String(q.query.course || ''); if (!CS.includes(c) || !can(q.user, c)) return s.status(403).json({ error: 'Нет доступа к этому курсу' }); s.json(db.prepare('SELECT id,kind,title FROM lessons WHERE course=? ORDER BY pos,id').all(c)); });
app.get('/api/lessons/:id', auth, (q, s) => {
  const l = db.prepare('SELECT id,kind,title,body,video,course FROM lessons WHERE id=?').get(id(q.params.id));
  if (!l) return s.status(404).json({ error: 'Не найдено' });
  if (!can(q.user, l.course)) return s.status(403).json({ error: 'Нет доступа к этому курсу' });
  l.questions = db.prepare('SELECT id,text,opts FROM questions WHERE lesson_id=? ORDER BY id').all(l.id).map(x => ({ ...x, opts: JSON.parse(x.opts) }));
  l.last = db.prepare('SELECT score,total,at FROM results WHERE user_id=? AND lesson_id=? ORDER BY id DESC').get(q.user.id, l.id) || null;
  l.hasVideo = !!l.video; delete l.video; s.json(l);
});
app.post('/api/lessons/:id/submit', auth, (q, s) => {
  const lid = id(q.params.id), lc = db.prepare('SELECT course FROM lessons WHERE id=?').get(lid);
  if (!lc || !can(q.user, lc.course)) return s.status(403).json({ error: 'Нет доступа к этому курсу' });
  const qs = db.prepare('SELECT id,correct FROM questions WHERE lesson_id=?').all(lid);
  if (!qs.length) return s.status(404).json({ error: 'Нет вопросов' });
  const a = q.body.answers && typeof q.body.answers === 'object' ? q.body.answers : {}; let score = 0; const ok = {}, now = Date.now();
  qs.forEach(x => { ok[x.id] = a[x.id] === x.correct; if (ok[x.id]) score++; db.prepare('INSERT INTO answers(user_id,lesson_id,question_id,correct,at) VALUES(?,?,?,?,?)').run(q.user.id, lid, x.id, ok[x.id] ? 1 : 0, now); });
  db.prepare('INSERT INTO results(user_id,lesson_id,score,total,at) VALUES(?,?,?,?,?)').run(q.user.id, lid, score, qs.length, now);
  s.json({ score, total: qs.length, ok });
});
app.get('/api/results', auth, (q, s) => s.json(db.prepare(`SELECT l.id,l.title,r.score,r.total,r.at FROM lessons l JOIN results r ON r.lesson_id=l.id WHERE r.user_id=? AND r.id=(SELECT MAX(id) FROM results WHERE user_id=r.user_id AND lesson_id=r.lesson_id) ORDER BY l.pos,l.id`).all(q.user.id)));
app.delete('/api/results', auth, (q, s) => { clearHistory(q.user.id); s.json({ ok: 1 }); });
app.get('/api/lessons/:id/video', auth, (q, s) => {
  const l = db.prepare('SELECT video,course FROM lessons WHERE id=?').get(id(q.params.id));
  if (!l || !l.video) return s.status(404).end(); if (!can(q.user, l.course)) return s.status(403).end();
  s.sendFile(path.join(UP, l.video), { dotfiles: 'allow', headers: { 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' } });
});

// ---------- админ ----------
app.post('/api/admin/login', (q, s) => {
  const k = 'a:' + q.ip, w = wait(k); if (w) return tooMany(s, w);
  const a = str(q.body.login, 64) || '', b = str(q.body.password, 128) || '';
  if (!(eq(a, ADMIN_USER) & eq(b, ADMIN_PASS))) { fail(k, 5, 5 * 60e3); return s.status(401).json({ error: 'Неверные данные' }); }
  fails.delete(k); const t = rnd(); admins.set(sha(t), Date.now() + 8 * HOUR);
  s.cookie('asid', t, cookie(8 * HOUR)).json({ ok: 1 });
});
app.post('/api/admin/logout', adm, (q, s) => { admins.delete(sha(getC(q, 'asid'))); s.clearCookie('asid').json({ ok: 1 }); });
app.get('/api/admin/users', adm, (q, s) => s.json(db.prepare('SELECT id,login,ip,created,pkg,courses,(SELECT COUNT(*) FROM devices WHERE user_id=users.id) devices FROM users ORDER BY id DESC').all()));
app.post('/api/admin/users', adm, (q, s) => {
  const l = str(q.body.login, 64); if (!l) return s.status(400).json({ error: 'Укажите логин' });
  const given = str(q.body.password, 128); if (given && given.length < 8) return s.status(400).json({ error: 'Пароль — минимум 8 символов' });
  const p = given || crypto.randomBytes(9).toString('base64url');
  try { const r = db.prepare('INSERT INTO users(login,hash,created) VALUES(?,?,?)').run(l, bcrypt.hashSync(p, 12), Date.now()); s.json({ id: Number(r.lastInsertRowid), login: l, password: p }); }
  catch { s.status(400).json({ error: 'Такой логин уже есть' }); }
});
app.post('/api/admin/users/:id/reset', adm, (q, s) => { const u = id(q.params.id); db.prepare('DELETE FROM devices WHERE user_id=?').run(u); db.prepare('UPDATE users SET ip=NULL,sid=NULL WHERE id=?').run(u); s.json({ ok: 1 }); });
app.put('/api/admin/users/:id/access', adm, (q, s) => {
  const pk = q.body.pkg == null || q.body.pkg === '' ? null : String(q.body.pkg); if (pk && !PKGS.includes(pk)) return s.status(400).json({ error: 'Неизвестный пакет' });
  const cs = (Array.isArray(q.body.courses) ? q.body.courses : []).filter(c => CS.includes(c));
  db.prepare('UPDATE users SET pkg=?,courses=? WHERE id=?').run(pk, [...new Set(cs)].join(','), id(q.params.id)); s.json({ ok: 1 });
});
app.delete('/api/admin/users/:id/answers', adm, (q, s) => { clearHistory(id(q.params.id)); s.json({ ok: 1 }); });
app.delete('/api/admin/users/:id', adm, (q, s) => { const u = id(q.params.id); clearHistory(u); db.prepare('DELETE FROM devices WHERE user_id=?').run(u); db.prepare('DELETE FROM users WHERE id=?').run(u); s.json({ ok: 1 }); });
app.get('/api/admin/lessons', adm, (q, s) => s.json(db.prepare('SELECT id,kind,title,pos,course FROM lessons ORDER BY pos,id').all()));
app.get('/api/admin/lessons/:id', adm, (q, s) => {
  const l = db.prepare('SELECT * FROM lessons WHERE id=?').get(id(q.params.id)); if (!l) return s.status(404).json({ error: 'Нет' });
  l.questions = db.prepare('SELECT * FROM questions WHERE lesson_id=?').all(l.id).map(x => ({ ...x, opts: JSON.parse(x.opts) })); s.json(l);
});
app.post('/api/admin/lessons', adm, (q, s) => {
  const t = str(q.body.title, 200); if (!t) return s.status(400).json({ error: 'Нужен заголовок' });
  const r = db.prepare('INSERT INTO lessons(kind,title,body,course) VALUES(?,?,?,?)').run(q.body.kind === 'test' ? 'test' : 'lesson', t, String(q.body.body || '').slice(0, 50000), CS.includes(q.body.course) ? q.body.course : 'ai');
  db.prepare('UPDATE lessons SET pos=id WHERE id=?').run(r.lastInsertRowid); s.json({ id: Number(r.lastInsertRowid) });
});
app.put('/api/admin/lessons/:id', adm, (q, s) => {
  const t = str(q.body.title, 200); if (!t) return s.status(400).json({ error: 'Нужен заголовок' });
  db.prepare('UPDATE lessons SET title=?,body=?,course=? WHERE id=?').run(t, String(q.body.body || '').slice(0, 50000), CS.includes(q.body.course) ? q.body.course : 'ai', id(q.params.id)); s.json({ ok: 1 });
});
app.delete('/api/admin/lessons/:id', adm, (q, s) => {
  const lid = id(q.params.id), v = db.prepare('SELECT video FROM lessons WHERE id=?').get(lid); if (v && v.video) fs.unlink(path.join(UP, v.video), () => {});
  for (const t of ['answers', 'questions', 'results']) db.prepare(`DELETE FROM ${t} WHERE lesson_id=?`).run(lid);
  db.prepare('DELETE FROM lessons WHERE id=?').run(lid); s.json({ ok: 1 });
});
app.post('/api/admin/lessons/:id/questions', adm, (q, s) => {
  const t = str(q.body.text, 500), o = (Array.isArray(q.body.opts) ? q.body.opts : []).map(x => str(x, 300)).filter(Boolean), c = q.body.correct;
  if (!t || o.length < 2 || !Number.isInteger(c) || c < 0 || c >= o.length) return s.status(400).json({ error: 'Нужен вопрос, минимум 2 варианта и верный ответ' });
  db.prepare('INSERT INTO questions(lesson_id,text,opts,correct) VALUES(?,?,?,?)').run(id(q.params.id), t, JSON.stringify(o), c); s.json({ ok: 1 });
});
app.delete('/api/admin/questions/:id', adm, (q, s) => { db.prepare('DELETE FROM questions WHERE id=?').run(id(q.params.id)); s.json({ ok: 1 }); });
app.get('/api/admin/results', adm, (q, s) => s.json(db.prepare('SELECT u.login,l.title,r.score,r.total,r.at FROM results r JOIN users u ON u.id=r.user_id JOIN lessons l ON l.id=r.lesson_id ORDER BY r.id DESC LIMIT 1000').all()));
app.get('/api/admin/backup', adm, (q, s) => { const f = safeBackup(); if (!f) return s.status(500).json({ error: 'Не удалось сделать копию' }); s.download(f, 'nebula-backup.db', { dotfiles: 'allow' }); });

// загрузка видео: проверяем тип, размер и реальное содержимое файла (а не только заголовок)
const sniff = (file, ext) => { try { const fd = fs.openSync(file, 'r'), b = Buffer.alloc(12); fs.readSync(fd, b, 0, 12, 0); fs.closeSync(fd); return ext === 'mp4' ? b.toString('latin1', 4, 8) === 'ftyp' : b.readUInt32BE(0) === 0x1A45DFA3; } catch { return false; } };
app.put('/api/admin/lessons/:id/video', adm, (q, s) => {
  const l = db.prepare('SELECT id,video FROM lessons WHERE id=?').get(id(q.params.id)); if (!l) return s.status(404).json({ error: 'Нет такого урока' });
  const ext = VT[(q.get('content-type') || '').split(';')[0]]; if (!ext) return s.status(400).json({ error: 'Только MP4 или WebM' });
  if (+q.get('content-length') > MAXV) return s.status(413).json({ error: 'Файл слишком большой' });
  const name = `l${l.id}-${Date.now()}.${ext}`, tmp = path.join(UP, name + '.part'), w = fs.createWriteStream(tmp); let n = 0, bad = false;
  q.on('data', c => { n += c.length; if (n > MAXV && !bad) { bad = true; q.unpipe(w); w.destroy(); fs.unlink(tmp, () => {}); s.status(413).set('Connection', 'close').json({ error: 'Файл слишком большой' }); } });
  q.pipe(w); q.on('aborted', () => { w.destroy(); fs.unlink(tmp, () => {}); });
  w.on('finish', () => {
    if (bad) return;
    if (!sniff(tmp, ext)) { fs.unlink(tmp, () => {}); return s.status(400).json({ error: 'Файл не похож на настоящее видео MP4/WebM' }); }
    fs.renameSync(tmp, path.join(UP, name)); if (l.video) fs.unlink(path.join(UP, l.video), () => {});
    db.prepare('UPDATE lessons SET video=? WHERE id=?').run(name, l.id); s.json({ ok: 1 });
  });
  w.on('error', () => { if (!s.headersSent) s.status(500).json({ error: 'Ошибка записи файла' }); });
});
app.delete('/api/admin/lessons/:id/video', adm, (q, s) => { const lid = id(q.params.id), l = db.prepare('SELECT video FROM lessons WHERE id=?').get(lid); if (l && l.video) fs.unlink(path.join(UP, l.video), () => {}); db.prepare('UPDATE lessons SET video=NULL WHERE id=?').run(lid); s.json({ ok: 1 }); });
app.get('/api/admin/faq', adm, (q, s) => s.json(db.prepare('SELECT id,title,body FROM faq ORDER BY pos,id').all()));
app.post('/api/admin/faq', adm, (q, s) => { const t = str(q.body.title, 200); if (!t) return s.status(400).json({ error: 'Нужен заголовок' }); const r = db.prepare('INSERT INTO faq(title,body) VALUES(?,?)').run(t, String(q.body.body || '').slice(0, 5000)); db.prepare('UPDATE faq SET pos=id WHERE id=?').run(r.lastInsertRowid); s.json({ id: Number(r.lastInsertRowid) }); });
app.put('/api/admin/faq/:id', adm, (q, s) => { const t = str(q.body.title, 200); if (!t) return s.status(400).json({ error: 'Нужен заголовок' }); db.prepare('UPDATE faq SET title=?,body=? WHERE id=?').run(t, String(q.body.body || '').slice(0, 5000), id(q.params.id)); s.json({ ok: 1 }); });
app.delete('/api/admin/faq/:id', adm, (q, s) => { db.prepare('DELETE FROM faq WHERE id=?').run(id(q.params.id)); s.json({ ok: 1 }); });

// ---------- страницы ----------
const PUB = path.join(__dirname, 'public');
app.get('/admin', (q, s) => s.sendFile(path.join(PUB, 'admin.html')));
app.use('/api', (q, s) => s.status(404).json({ error: 'Не найдено' }));
app.use(express.static(PUB, { index: 'index.html', dotfiles: 'deny' }));
app.use((err, q, s, n) => { // любые ошибки — аккуратный JSON, без стека и без падения сервера
  if (s.headersSent) return n(err);
  if (err.type === 'entity.parse.failed') return s.status(400).json({ error: 'Неверный запрос' });
  console.error(err); s.status(500).json({ error: 'Ошибка сервера. Попробуйте ещё раз.' });
});
process.on('uncaughtException', e => console.error('uncaughtException:', e));
process.on('unhandledRejection', e => console.error('unhandledRejection:', e));

const PORT = env.PORT || 3000;
const srv = app.listen(PORT, () => console.log(`Сайт: http://localhost:${PORT}  Админка: /admin`));
srv.requestTimeout = 0; srv.keepAliveTimeout = 65e3;
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => { srv.close(() => process.exit(0)); setTimeout(() => process.exit(0), 5e3).unref(); });
